/* ===== Expense Tracker =====
 * Vanilla JS + localStorage + Chart.js
 */

const STORAGE_KEY = "expense-tracker-transactions";

let transactions = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
let chart = null;

// ---- DOM references ----
const form = document.getElementById("transaction-form");
const typeInput = document.getElementById("type");
const descInput = document.getElementById("description");
const amountInput = document.getElementById("amount");
const categoryInput = document.getElementById("category");
const dateInput = document.getElementById("date");
const listEl = document.getElementById("transaction-list");
const emptyMessage = document.getElementById("empty-message");
const filterCategory = document.getElementById("filter-category");
const clearAllBtn = document.getElementById("clear-all");

// Default date = today
dateInput.valueAsDate = new Date();

// ---- Save / Load ----
function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
}

// ---- Currency formatting ----
function formatINR(value) {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    maximumFractionDigits: 2,
  }).format(value);
}

// ---- Totals ----
function updateSummary() {
  const income = transactions
    .filter((t) => t.type === "income")
    .reduce((sum, t) => sum + t.amount, 0);
  const expense = transactions
    .filter((t) => t.type === "expense")
    .reduce((sum, t) => sum + t.amount, 0);

  document.getElementById("total-income").textContent = formatINR(income);
  document.getElementById("total-expense").textContent = formatINR(expense);
  document.getElementById("total-balance").textContent = formatINR(income - expense);
}

// ---- Transaction list ----
function renderList() {
  const filter = filterCategory.value;
  const visible = transactions
    .filter((t) => filter === "all" || t.category === filter)
    .sort((a, b) => new Date(b.date) - new Date(a.date));

  listEl.innerHTML = "";

  visible.forEach((t) => {
    const li = document.createElement("li");
    li.className = `transaction ${t.type}`;
    li.innerHTML = `
      <div class="info">
        <span class="desc">${escapeHTML(t.description)}</span>
        <span class="meta">${t.category} · ${t.date}</span>
      </div>
      <span class="amount">${t.type === "income" ? "+" : "−"}${formatINR(t.amount)}</span>
      <button class="delete-btn" title="Delete">&times;</button>
    `;
    li.querySelector(".delete-btn").addEventListener("click", () => {
      transactions = transactions.filter((x) => x.id !== t.id);
      save();
      renderAll();
    });
    listEl.appendChild(li);
  });

  emptyMessage.classList.toggle("hidden", visible.length > 0);
}

function escapeHTML(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// ---- Chart ----
function renderChart() {
  const byCategory = {};
  transactions
    .filter((t) => t.type === "expense")
    .forEach((t) => {
      byCategory[t.category] = (byCategory[t.category] || 0) + t.amount;
    });

  const labels = Object.keys(byCategory);
  const data = Object.values(byCategory);

  if (chart) chart.destroy();
  chart = new Chart(document.getElementById("category-chart"), {
    type: "doughnut",
    data: {
      labels: labels.length ? labels : ["No expenses yet"],
      datasets: [
        {
          data: data.length ? data : [1],
          backgroundColor: [
            "#f87171", "#fbbf24", "#34d399", "#60a5fa",
            "#c084fc", "#f472b6", "#818cf8",
          ],
          borderWidth: 0,
        },
      ],
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { position: "right", labels: { color: "#e2e8f0" } },
      },
    },
  });
}

function renderAll() {
  updateSummary();
  renderList();
  renderChart();
}

// ---- Events ----
form.addEventListener("submit", (e) => {
  e.preventDefault();

  const transaction = {
    id: Date.now(),
    type: typeInput.value,
    description: descInput.value.trim(),
    amount: Math.round(parseFloat(amountInput.value) * 100) / 100,
    category: categoryInput.value,
    date: dateInput.value,
  };

  if (!transaction.description || !transaction.amount || !transaction.date) return;

  transactions.push(transaction);
  save();
  renderAll();
  form.reset();
  dateInput.valueAsDate = new Date();
});

filterCategory.addEventListener("change", renderList);

clearAllBtn.addEventListener("click", () => {
  if (transactions.length === 0) return;
  if (confirm("Delete ALL transactions? This cannot be undone.")) {
    transactions = [];
    save();
    renderAll();
  }
});

// ---- Init ----
renderAll();
